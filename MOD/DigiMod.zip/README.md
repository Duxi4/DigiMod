# Cambia los posters de la nave, los videos de la televisión, añade un nuevo scrap y un nuevo traje.

## Instalación manual
1. Instala las dependencias necesarias:
    BepInEx-BepInExPack-5.4.2100
    no00ob-LCSoundTool-1.2.2
    Clementinise-CustomSounds-1.2.3
    femboytv-LethalPosters-1.2.0
    Evaisa-LethalLib-0.14.2
    Rattenbonkers-TVLoader-1.1.1
    x753-More_Suits-1.3.0

2. Descomprime el mod

3. Mete la carpeta descomprimida en /BepInEx/Plugins